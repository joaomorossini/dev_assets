import os
from crewai import Agent, Task, Crew


# Define the agents
text_analyzer = Agent(
    role="Text Analyzer",
    goal=(
        "Analisar criticamente os documentos de licitação para identificar tópicos-chave e seções correspondentes, "
        "como prazos de submissão, critérios financeiros e condições específicas de participação. "
        "Este agente gera uma lista de tópicos com as seções relevantes do documento."
        "NUNCA invente informações, sempre extraia dos documentos originais."
    ),
    backstory=(
        "Um especialista em entender e resumir documentos complexos, capaz de extrair e categorizar informações críticas."
    ),
    model="gpt-4o",
    temperature=0.4,
    verbose=True,
    memory=True,
    allow_delegation=False,
)

verifier = Agent(
    role="Professional Verifier",
    goal=(
        "Verificar a precisão das informações extraídas e garantir que estejam consistentes com os documentos de licitação originais. "
        "Este agente faz a verificação cruzada dos dados extraídos com os documentos originais para confirmar sua validade."
    ),
    backstory=(
        "Um verificador meticuloso com um olhar atento aos detalhes, garantindo que todas as informações extraídas sejam precisas e confiáveis."
    ),
    model="gpt-4o",
    temperature=0.0,
    verbose=True,
    memory=True,
    allow_delegation=False,
)

requirements_gatherer = Agent(
    role="Requirements Gatherer",
    goal=(
        "Extrair e compilar todos os requisitos necessários para a submissão de uma proposta com base nos tópicos identificados. "
        "Isso inclui detalhes como prazos, critérios financeiros e condições específicas de participação."
    ),
    backstory=(
        "Um especialista em extração detalhada, garantindo que todos os requisitos críticos para a submissão da proposta sejam capturados com precisão."
    ),
    model="gpt-4",
    temperature=0.4,
    verbose=True,
    memory=True,
    allow_delegation=False,
)

summary_compiler = Agent(
    role="Summary Compiler",
    goal=(
        "Compilar um resumo em Markdown dos documentos de licitação, incluindo as seções mais relevantes e uma lista abrangente de requisitos. "
        "Este agente verifica a precisão das informações extraídas e garante que estejam fundamentadas nos documentos originais."
    ),
    backstory=(
        "Um compilador meticuloso garantindo precisão e clareza na documentação, capaz de destilar informações complexas em um resumo coerente e conciso."
    ),
    model="gpt-4",
    temperature=0,
    verbose=True,
    memory=True,
    allow_delegation=True,
)

# Define the tasks
text_analysis_task = Task(
    description=(
        "Analisar os documentos de licitação fornecidos para identificar e categorizar tópicos-chave. Extrair seções correspondentes que detalham esses tópicos."
    ),
    expected_output=(
        "Uma lista de dicionários, cada um contendo um tópico e a seção associada dos documentos de licitação."
    ),
    agent=text_analyzer
)

verifier_task = Task(
    description=(
        "Verificar a precisão das informações extraídas e fazer a verificação cruzada com os documentos de licitação originais para confirmar sua validade."
    ),
    expected_output=(
        "Uma lista de dicionários, cada um contendo um tópico, a seção associada e um status de verificação indicando a precisão das informações extraídas."
    ),
    agent=verifier
)

requirements_gathering_task = Task(
    description=(
        "Para cada tópico identificado, reunir todos os requisitos relevantes necessários para a submissão de uma proposta. Isso inclui prazos, valores financeiros e condições específicas de participação."
    ),
    expected_output=(
        "Uma lista atualizada de dicionários, cada um contendo um tópico, a seção associada e uma lista de requisitos."
    ),
    agent=requirements_gatherer
)

summary_compilation_task = Task(
    description=(
        "Compilar um resumo abrangente em Markdown dos documentos de licitação. O resumo deve incluir as seções mais relevantes, organizadas por tópico, e uma lista de verificação de todos os requisitos para submissão. "
        "Verificar que todas as informações são precisas e extraídas dos documentos originais."
    ),
    expected_output=(
        "Um arquivo Markdown chamado summary.md contendo o resumo compilado e a lista de verificação."
    ),
    agent=summary_compiler,
    output_file="summary.md"
)

# Assemble the crew
crew = Crew(
    agents=[text_analyzer, verifier, requirements_gatherer, summary_compiler],
    tasks=[text_analysis_task, verifier_task, requirements_gathering_task, summary_compilation_task],
    verbose=2
)

# Read multiple Markdown documents
documents = {}

# Define the file paths
file_paths = [
    "/Users/morossini/Projects/Prototypes/Cogmo/LicitaBot/tender_summary_crew/docs/edital.md",
    # "/Users/morossini/Projects/Prototypes/Cogmo/LicitaBot/tender_summary_crew/docs/modelo_proposta.md"
]

for i, file_path in enumerate(file_paths):
    with open(file_path, 'r') as file:
        documents[f'markdown_document_{i+1}'] = file.read()

result = crew.kickoff(inputs=documents)

# Save the final output
with open("summary.md", "w") as f:
    f.write(result)

# Output the path to the final summary file
print("Summary compiled at:", result)

# Print the result
print(f"\n\nComplete results: \n{result}\n\n")

if __name__ == "__main__":
    print(documents)